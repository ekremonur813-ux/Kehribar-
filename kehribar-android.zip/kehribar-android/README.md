# Kehribar (Android uygulaması)

Telefona kurulan, sunucusuz, Türkçe konuşan kişisel yapay zekâ asistanı (krem ve kehribar tema).

APK'yı telefondan nasıl alacağın için sohbetteki "APK-NASIL-ALINIR" rehberine bak.
Bu zip'i AÇMA; olduğu gibi GitHub'a yükle, derleyici kendisi açar.
